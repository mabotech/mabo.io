

s = u'AsyncRefresh: \u672a\u6307\u5b9a\u7684\u9519\u8bef  (Unspecified error)'


print type(s) == unicode

print s.encode("utf8")
