#App config
#webx

#central config
CENTRAL_CONFIG = 'c:/mtp/avl_dc/bli_monitor/conf/maboss_config.py'

#windows service
SERVICE_NAME = '_MaboTech_Monitor_HotTest'

SERVICE_DESC = 'HotTest Data Collection'

