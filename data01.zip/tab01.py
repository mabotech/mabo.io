

s = "mt_t_test_serialno_his_id_seq"

print len(s)


s = "mt_t_id_seq"

print len(s)


s = "mt_seq_test_serialno_his"

print len(s)